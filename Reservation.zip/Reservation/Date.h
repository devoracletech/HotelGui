#ifndef DATE_H
#define DATE_H

class Date
{
public:

	Date(int = 1, int = 1, int = 1900);
	void setDate(int, int, int);
	void setMonth(int);
	void setDay(int);
	void setYear(int);
	int getDay() const;
	int getMonth() const;
	int getYear() const;

	void nextDay();
	void prevDay();
	void print() const;


	//Overloaded operators
	Date& operator=(const Date &other);

	Date& operator+=(int numOfDays);
	Date& operator-=(int numOfDays);
	const Date operator+(int numOfDays) const;
	const Date operator-(int numOfDays) const;

	void operator++();
	void operator--();
	Date operator++(int);
	Date operator--(int);

	bool operator==(const Date &other) const;
	bool operator!=(const Date &other) const;
	bool operator>(const Date &other) const;
	bool operator<(const Date &other) const;
	bool operator>=(const Date &other) const;
	bool operator<=(const Date &other) const;

private:
	int year, month, day;
	bool leapYear();
	int monthDays();
	int monthDays(int);

};

#endif 
