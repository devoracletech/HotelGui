#include "Reservation.h"


Reservation::Reservation()
{
	generalInfo = new GeneralInfo();
	requiredInfo = new RequiredInfo();
	extraInfo = new ExtraFeatures();
}

Reservation::Reservation(GeneralInfo& newGeneralInfo, RequiredInfo& newRequiredInfo, ExtraFeatures& newExtraInfo, CreditCard& newCreditInfo)
{
	generalInfo = &newGeneralInfo;
	requiredInfo = &newRequiredInfo;
	extraInfo = &newExtraInfo;
	creditInfo = &newCreditInfo;
}

void Reservation::setGeneralInfo(GeneralInfo& newGeneralInfo)
{
	generalInfo = &newGeneralInfo;
}

GeneralInfo& Reservation::getGeneralInfo() const
{
	return *generalInfo;
}

void Reservation::setRequiredInfo(RequiredInfo& newRequiredInfo)
{
	requiredInfo = &newRequiredInfo;
}

RequiredInfo& Reservation::getRequiredInfo() const
{
	return *requiredInfo;
}

void Reservation::setExtraInfo(ExtraFeatures& newExtraInfo)
{
	extraInfo = &newExtraInfo;
}

ExtraFeatures& Reservation::getExtraInfo() const
{
	return *extraInfo;
}

void Reservation::setCreditInfo(CreditCard& newCreditInfo)
{
	creditInfo = &newCreditInfo;
}

CreditCard& Reservation::getCreditInfo() const
{
	return *creditInfo;
}

void Reservation::print() const
{
	generalInfo->print();
}

Reservation::~Reservation()
{
	generalInfo->~GeneralInfo();
	delete [] generalInfo;
	generalInfo = NULL;

	requiredInfo->~RequiredInfo();
	delete [] requiredInfo;
	requiredInfo = NULL;

	extraInfo->~ExtraFeatures();
	delete [] extraInfo;
	extraInfo = NULL;

	creditInfo->~CreditCard();
	delete[] creditInfo;
	creditInfo = NULL;
}
