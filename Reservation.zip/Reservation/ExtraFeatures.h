#ifndef EXTRAFEATURES_H
#define EXTRAFEATURES_H

#include <iostream>
#include <string>
using namespace std;

class ExtraFeatures
{
public:
	ExtraFeatures();
	ExtraFeatures(string newText, int newId);

	void setUserText(string newText);
	string getUserText() const;

	void setGroupId(int newId);
	int getGroupId() const;

	ExtraFeatures& operator=(const ExtraFeatures& other);

	~ExtraFeatures();
private:
	string userText;
	int groupId;
};

#endif
