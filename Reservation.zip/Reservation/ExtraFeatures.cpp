#include "ExtraFeatures.h"


ExtraFeatures::ExtraFeatures()
{
	userText = "";
	groupId = 0;
}

ExtraFeatures::ExtraFeatures(string newText, int newId)
{
	userText = newText;
	groupId = newId;
}

void ExtraFeatures::setUserText(string newText)
{
	userText = newText;
}

string ExtraFeatures::getUserText() const
{
	return userText;
}

void ExtraFeatures::setGroupId(int newId)
{
	groupId = newId;
}

int ExtraFeatures::getGroupId() const
{
	return groupId;
}

ExtraFeatures& ExtraFeatures::operator=(const ExtraFeatures& other)
{
	if(&other != this)
	{
		userText = other.getUserText();
		groupId = other.getGroupId();
	}
	else
		cerr << "Attempted assignment to itself.";

	return *this;
}


ExtraFeatures::~ExtraFeatures()
{
	userText = "";
	groupId = 0;
}
