#ifndef RESERVATION_H
#define RESERVATION_H

#include <iostream>
#include <string>
#include "GeneralInfo.h"
#include "ExtraFeatures.h"
#include "RequiredInfo.h"
#include "CreditCard.h"
#include "Date.h"

using namespace std;

class Reservation
{
public:
	Reservation();

	Reservation(GeneralInfo& newGeneralInfo, RequiredInfo& newRequiredInfo, ExtraFeatures& newExtraInfo, CreditCard& newCreditInfo);

	void setGeneralInfo(GeneralInfo& newGeneralInfo);
	GeneralInfo&  getGeneralInfo() const;

	void setRequiredInfo(RequiredInfo& newRequiredInfo);
	RequiredInfo& getRequiredInfo() const;

	void setExtraInfo(ExtraFeatures& newExtraInfo);
	ExtraFeatures& getExtraInfo() const;

	void setCreditInfo(CreditCard& newCreditInfo);
	CreditCard& getCreditInfo() const;

	void print() const;

	~Reservation();
private:
	GeneralInfo *generalInfo;
	RequiredInfo *requiredInfo;
	ExtraFeatures *extraInfo;
	CreditCard *creditInfo;

};

#endif
